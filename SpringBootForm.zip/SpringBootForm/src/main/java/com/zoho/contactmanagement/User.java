package com.zoho.contactmanagement;

public class User {
	private long id;
	private String name;
	private String email;
	private String password;
	private String pno;
	private String secret;

	public User() {
		id = 0;
	}

	public User(long id, String name, String email, String password, String pno, String secret) {
		super();
		this.id = id;
		this.name = name;
		this.email = email;
		this.password = password;
		this.pno = pno;
		this.secret = secret;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getPno() {
		return pno;
	}

	public void setPno(String pno) {
		this.pno = pno;
	}

	public String getSecret() {
		return secret;
	}

	public void setSecret(String secret) {
		this.secret = secret;
	}

	@Override
	public String toString() {
		return "User [id=" + id + ", name=" + name + ", email=" + email + ", password=" + password + ", pno=" + pno
				+ ", secret=" + secret + "]";
	}
}
